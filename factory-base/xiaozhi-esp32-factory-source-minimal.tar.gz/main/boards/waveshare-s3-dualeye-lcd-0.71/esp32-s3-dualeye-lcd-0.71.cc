#include "wifi_board.h"
#include "codecs/es8311_audio_codec.h"
#include "display/lcd_display.h"
#include "system_reset.h"
#include "application.h"
#include "button.h"
#include "config.h"

#include <esp_log.h>
#include "i2c_device.h"
#include <driver/i2c.h>
#include <driver/ledc.h>
#include <wifi_station.h>
#include <esp_lcd_panel_vendor.h>
#include <esp_lcd_panel_io.h>
#include <esp_lcd_panel_ops.h>
#include <esp_timer.h>
#include "esp_io_expander_tca95xx_16bit.h"
#include <driver/spi_common.h>
#include "display_manager.h"
#include "assets/lang_config.h"
#include "display/lvgl_display/lvgl_theme.h"
#include "esp32_camera.h"

#include "esp_lcd_gc9d01n.h"
#include <esp_lvgl_port.h>
#include <cstring>

#define TAG "waveshare_s3_dualeye_lcd_0_71"

// ================= 日志监控与拦截逻辑 =================
static vprintf_like_t default_vprintf = NULL;

/**
 * @brief 自定义日志拦截函数
 * 当系统日志中出现摄像头识别失败的关键字时，强制重启
 */
static int camera_log_monitor_vprintf(const char *fmt, va_list l) {
    char buffer[128]; 
    va_list aq;
    va_copy(aq, l);
    vsnprintf(buffer, sizeof(buffer), fmt, aq);
    va_end(aq);

    if (strstr(buffer, "Camera sensor is not OV5640") != NULL  || strstr(buffer, "ov5640_get_sensor_id") != NULL) {
        printf("\n检测到摄像头硬件异常，系统即将自动复位...\n");
        fflush(stdout);
        vTaskDelay(pdMS_TO_TICKS(500));
        esp_restart();
    }

    return default_vprintf(fmt, l);
}

// Use a conservative SPI clock during panel bring-up to reduce command crosstalk risk.
#define DISPLAY_SPI_INIT_SCLK_HZ    (80 * 1000 * 1000)

class CustomBoard : public WifiBoard {
private:
    class StandbyRefreshDisplayManager : public DisplayManager {
    private:
        bool was_listening_ = false;

        void RefreshWhiteBackground() {
            auto light_theme = LvglThemeManager::GetInstance().GetTheme("light");
            if (light_theme != nullptr) {
                DisplayManager::SetTheme(light_theme);
            }
            DisplayManager::SetChatMessage("system", " ");
            DisplayManager::SetChatMessage("system", "");
        }

    public:
        virtual void SetStatus(const char* status) override {
            DisplayManager::SetStatus(status);

            const bool is_standby = (status != nullptr && std::strcmp(status, Lang::Strings::STANDBY) == 0);
            if (!is_standby) {
                return;
            }

            // Always refresh when standby status is set to ensure first standby also repaints.
            RefreshWhiteBackground();
        }

        virtual void SetChatMessage(const char* role, const char* content) override {
            DisplayManager::SetChatMessage(role, content);

            const bool is_listening =
                (role != nullptr && std::strcmp(role, "system") == 0) &&
                (content != nullptr && std::strcmp(content, Lang::Strings::LISTENING) == 0);

            // Refresh once when transitioning into listening.
            if (is_listening && !was_listening_) {
                RefreshWhiteBackground();
            }
            was_listening_ = is_listening;
        }
    };

    Button boot_button_;
    i2c_master_bus_handle_t i2c_bus_;
    esp_io_expander_handle_t io_expander = NULL;
    LcdDisplay* display_;
    LcdDisplay* display2_;
    StandbyRefreshDisplayManager display_manager_;
    Esp32Camera* camera_;

    void InitializeI2c() {
        // Initialize I2C peripheral
        i2c_master_bus_config_t i2c_bus_cfg = {
            .i2c_port = (i2c_port_t)0,
            .sda_io_num = I2C_SDA_IO,
            .scl_io_num = I2C_SCL_IO,
            .clk_source = I2C_CLK_SRC_DEFAULT,
        };
        ESP_ERROR_CHECK(i2c_new_master_bus(&i2c_bus_cfg, &i2c_bus_));
    }
    

    void InitializeSpi() {
        // Keep both LCD CS lines at inactive level before attaching SPI devices.
        // This avoids command crosstalk between two panels during bring-up.
        gpio_config_t cs_conf = {};
        cs_conf.mode = GPIO_MODE_OUTPUT;
        cs_conf.pin_bit_mask = (1ULL << DISPLAY_CS_PIN) | (1ULL << DISPLAY2_CS_PIN);
        ESP_ERROR_CHECK(gpio_config(&cs_conf));
        gpio_set_level(DISPLAY_CS_PIN, 1);
        gpio_set_level(DISPLAY2_CS_PIN, 1);

        spi_bus_config_t buscfg = {};
        buscfg.mosi_io_num = DISPLAY_MOSI_PIN;
        buscfg.miso_io_num = DISPLAY_MISO_PIN;
        buscfg.sclk_io_num = DISPLAY_SCLK_PIN;
        buscfg.quadwp_io_num = GPIO_NUM_NC;
        buscfg.quadhd_io_num = GPIO_NUM_NC;
        buscfg.max_transfer_sz = DISPLAY_WIDTH * DISPLAY_HEIGHT * sizeof(uint16_t);
        ESP_ERROR_CHECK(spi_bus_initialize(SPI3_HOST, &buscfg, SPI_DMA_CH_AUTO));
    }

    void InitializeLcdDisplay() {

        esp_lcd_panel_io_handle_t panel_io = nullptr;
        esp_lcd_panel_handle_t panel = nullptr;
        // 液晶屏控制IO初始化
        ESP_LOGD(TAG, "Install panel IO");
        esp_lcd_panel_io_spi_config_t io_config = {};
        io_config.cs_gpio_num = DISPLAY_CS_PIN;
        io_config.dc_gpio_num = DISPLAY_DC_PIN;
        io_config.spi_mode = DISPLAY_SPI_MODE;
        io_config.pclk_hz = DISPLAY_SPI_SCLK_HZ;
        io_config.trans_queue_depth = 10;
        io_config.lcd_cmd_bits = 8;
        io_config.lcd_param_bits = 8;
        ESP_ERROR_CHECK(esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)SPI3_HOST, &io_config, &panel_io));

        // 初始化液晶屏驱动芯片
        ESP_LOGD(TAG, "Install LCD driver");
        esp_lcd_panel_dev_config_t panel_config = {};
        panel_config.reset_gpio_num = DISPLAY_RESET_PIN;
        panel_config.rgb_ele_order = DISPLAY_RGB_ORDER;
        panel_config.bits_per_pixel = 16;
        ESP_ERROR_CHECK(esp_lcd_new_panel_gc9d01n(panel_io, &panel_config, &panel));    
        
        esp_lcd_panel_reset(panel);
        esp_lcd_panel_init(panel);
        esp_lcd_panel_invert_color(panel, DISPLAY_INVERT_COLOR);
        vTaskDelay(pdMS_TO_TICKS(20));

        display_ = new SpiLcdDisplayExtended(panel_io, panel,
                                    DISPLAY_WIDTH, DISPLAY_HEIGHT, DISPLAY_OFFSET_X, DISPLAY_OFFSET_Y, DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y, DISPLAY_SWAP_XY
                                    );
        ESP_ERROR_CHECK(panel_gc9d01n_swap_xy(panel, DISPLAY_SWAP_XY));
        ESP_ERROR_CHECK(panel_gc9d01n_mirror(panel, DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y));
    }

    void InitializeLcdDisplay_2() {

        esp_lcd_panel_io_handle_t panel_io = nullptr;
        esp_lcd_panel_handle_t panel = nullptr;
        // 液晶屏控制IO初始化
        ESP_LOGD(TAG, "Install panel IO");
        esp_lcd_panel_io_spi_config_t io_config = {};
        io_config.cs_gpio_num = DISPLAY2_CS_PIN;
        io_config.dc_gpio_num = DISPLAY_DC_PIN;
        io_config.spi_mode = DISPLAY_SPI_MODE;
        io_config.pclk_hz = DISPLAY_SPI_SCLK_HZ;
        io_config.trans_queue_depth = 10;
        io_config.lcd_cmd_bits = 8;
        io_config.lcd_param_bits = 8;
        ESP_ERROR_CHECK(esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)SPI3_HOST, &io_config, &panel_io));

        // 初始化液晶屏驱动芯片
        ESP_LOGD(TAG, "Install LCD driver");
        esp_lcd_panel_dev_config_t panel_config = {};
        panel_config.reset_gpio_num = DISPLAY2_RESET_PIN;
        panel_config.rgb_ele_order = DISPLAY_RGB_ORDER;
        panel_config.bits_per_pixel = 16;
        ESP_ERROR_CHECK(esp_lcd_new_panel_gc9d01n(panel_io, &panel_config, &panel));    
        
        esp_lcd_panel_reset(panel);
        esp_lcd_panel_init(panel);
        esp_lcd_panel_invert_color(panel, DISPLAY_INVERT_COLOR);
        vTaskDelay(pdMS_TO_TICKS(20));

        display2_ = new SpiLcdDisplayExtended(panel_io, panel,
                                    DISPLAY_WIDTH, DISPLAY_HEIGHT, DISPLAY_OFFSET_X, DISPLAY_OFFSET_Y, DISPLAY2_MIRROR_X, DISPLAY2_MIRROR_Y, DISPLAY2_SWAP_XY
                                    );
 
        ESP_ERROR_CHECK(panel_gc9d01n_swap_xy(panel, DISPLAY2_SWAP_XY));
        ESP_ERROR_CHECK(panel_gc9d01n_mirror(panel, DISPLAY2_MIRROR_X, DISPLAY2_MIRROR_Y));                                    
    }

    void InitializeButtons() {
        boot_button_.OnClick([this]() {
            auto& app = Application::GetInstance();
            if (app.GetDeviceState() == kDeviceStateStarting) {
                EnterWifiConfigMode();
                return;
            }
            app.ToggleChatState();
        });
    }

    void InitializeCamera() {
        static esp_cam_ctlr_dvp_pin_config_t dvp_pin_config = {
            .data_width = CAM_CTLR_DATA_WIDTH_8,
            .data_io = {
                [0] = CAMERA_PIN_D0,
                [1] = CAMERA_PIN_D1,
                [2] = CAMERA_PIN_D2,
                [3] = CAMERA_PIN_D3,
                [4] = CAMERA_PIN_D4,
                [5] = CAMERA_PIN_D5,
                [6] = CAMERA_PIN_D6,
                [7] = CAMERA_PIN_D7,
            },
            .vsync_io = CAMERA_PIN_VSYNC,
            .de_io = CAMERA_PIN_HREF,
            .pclk_io = CAMERA_PIN_PCLK,
            .xclk_io = CAMERA_PIN_XCLK,
        };

        esp_video_init_sccb_config_t sccb_config = {
            .init_sccb = false,
            .i2c_handle = i2c_bus_,
            .freq = 100000,
        };

        esp_video_init_dvp_config_t dvp_config = {
            .sccb_config = sccb_config,
            .reset_pin = CAMERA_PIN_RESET,
            .pwdn_pin = CAMERA_PIN_PWDN,
            .dvp_pin = dvp_pin_config,
            .xclk_freq = XCLK_FREQ_HZ,
        };

        esp_video_init_config_t video_config = {
            .dvp = &dvp_config,
        };

        camera_ = new Esp32Camera(video_config);
    }

public:
    CustomBoard() :
        boot_button_(BOOT_BUTTON_GPIO) {

        if (default_vprintf == NULL) {
            default_vprintf = esp_log_set_vprintf(camera_log_monitor_vprintf);
        }
        InitializeI2c();
        InitializeSpi();
        InitializeLcdDisplay();
        InitializeLcdDisplay_2();
        // vTaskDelay(pdMS_TO_TICKS(2000));
        
        InitializeButtons();
        InitializeCamera();
        GetBacklight()->RestoreBrightness();
        GetBacklight2()->RestoreBrightness();
        // Add two display devices to the manager
        DisplayManager::AddDisplay(display_);
        DisplayManager::AddDisplay(display2_);
        
        
        
    }

    virtual AudioCodec* GetAudioCodec() override {
        static Es8311AudioCodec audio_codec(i2c_bus_, I2C_NUM_0, AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
            AUDIO_I2S_GPIO_MCLK, AUDIO_I2S_GPIO_BCLK, AUDIO_I2S_GPIO_WS, AUDIO_I2S_GPIO_DOUT, AUDIO_I2S_GPIO_DIN,
            AUDIO_CODEC_PA_PIN, AUDIO_CODEC_ES8311_ADDR);
        return &audio_codec;
    }

    virtual Display* GetDisplay() override {
        return &display_manager_;
    }

    virtual Backlight* GetBacklight() override {
        static PwmBacklight backlight(DISPLAY_BACKLIGHT_PIN, DISPLAY_BACKLIGHT_OUTPUT_INVERT);
        return &backlight;
    }
    Backlight* GetBacklight2(){
        static PwmBacklight backlight(DISPLAY2_BACKLIGHT_PIN, DISPLAY_BACKLIGHT_OUTPUT_INVERT);
        return &backlight;
    }

    virtual Camera* GetCamera() override {
        return camera_;
    }
};

DECLARE_BOARD(CustomBoard);
